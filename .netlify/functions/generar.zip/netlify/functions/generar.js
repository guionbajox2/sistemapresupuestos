"use strict";

// netlify/functions/generar.js
var MAPA_CELDAS = {
  fechaSolicitud: "L2",
  organizacion: "H1",
  nombreLider: "D22",
  nombreReceptor_L8: "L8",
  nombreReceptor_G22: "G22",
  tipoSolicitud: "J9",
  nombreActividad: "E5",
  fechaActividad: "C6",
  horaActividad: "H6",
  lugar: "D7",
  cantidadAsistencia: "B8",
  dirigidaA: "C9",
  proposito: "A12",
  // Metas (marcar X)
  meta_edificarFe: "J18",
  meta_diversionUnidad: "J19",
  meta_crecimientoPersonal: "J21",
  meta_fortalecerFamilias: "J22",
  meta_obrasSalvacion: "J23",
  // Productos: filas 29..41
  // Se insertan dinámicamente dentro del bucle
  // Totales
  totalSolicitado_K42: "K42",
  totalSolicitado_L7: "L7"
};
var PRODUCTO_INICIO_FILA = 29;
var COLUMNA_CANTIDAD = "A";
var COLUMNA_PRODUCTO = "B";
var COLUMNA_COSTO_UNIT = "J";
var COLUMNA_COSTO_TOTAL = "K";
function sanitizeString(val) {
  if (typeof val !== "string") return "";
  let s = val.slice(0, 500).trim();
  if (s.startsWith("=") || s.startsWith("+") || s.startsWith("-") || s.startsWith("@")) {
    s = "'" + s;
  }
  return s;
}
function sanitizeNumber(val, min = 0, max = 9999999) {
  const n = parseFloat(val);
  if (isNaN(n)) return 0;
  return Math.max(min, Math.min(max, n));
}
function generarTextoTipoSolicitud(tipo) {
  if (tipo === "Anticipo") {
    return "ANTICIPO | X | REEMBOLSO |   |";
  } else if (tipo === "Reembolso") {
    return "ANTICIPO |   | REEMBOLSO | X |";
  }
  return "";
}
function setCellValue(ws, cellRef, value) {
  const cell = ws.getCell(cellRef);
  const existingStyle = cell.style ? JSON.parse(JSON.stringify(cell.style)) : {};
  cell.value = value;
  cell.style = existingStyle;
}
function validarDatos(data) {
  const errores = [];
  if (!data.fechaSolicitud) errores.push("fechaSolicitud es obligatorio");
  if (!data.organizacion) errores.push("organizacion es obligatorio");
  if (!data.nombreLider) errores.push("nombreLider es obligatorio");
  if (!data.nombreReceptor) errores.push("nombreReceptor es obligatorio");
  if (!data.tipoSolicitud) errores.push("tipoSolicitud es obligatorio");
  if (!data.nombreActividad) errores.push("nombreActividad es obligatorio");
  if (!data.fechaActividad) errores.push("fechaActividad es obligatorio");
  if (!data.lugar) errores.push("lugar es obligatorio");
  if (!data.proposito) errores.push("proposito es obligatorio");
  if (!data.cantidadAsistencia || data.cantidadAsistencia < 1)
    errores.push("cantidadAsistencia debe ser >= 1");
  if (!Array.isArray(data.metas) || data.metas.length === 0)
    errores.push("Debe seleccionar al menos una meta");
  if (!Array.isArray(data.productos) || data.productos.length === 0)
    errores.push("Debe incluir al menos un producto");
  if (data.productos.length > 13)
    errores.push("M\xE1ximo 13 productos permitidos");
  return errores;
}
exports.handler = async function(event, context) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "M\xE9todo no permitido. Use POST." })
    };
  }
  let data;
  try {
    if (!event.body) throw new Error("El cuerpo de la solicitud est\xE1 vac\xEDo.");
    data = JSON.parse(event.body);
  } catch (err) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "JSON inv\xE1lido: " + err.message })
    };
  }
  const errores = validarDatos(data);
  if (errores.length > 0) {
    return {
      statusCode: 422,
      body: JSON.stringify({ error: "Datos inv\xE1lidos: " + errores.join("; ") })
    };
  }
  try {
    const posiblesPaths = [
      // Producción Netlify: la función se ejecuta desde la raíz
      path.join(__dirname, "..", "..", "plantilla.xlsx"),
      // Netlify CLI local (a veces agrega un nivel extra)
      path.join(__dirname, "..", "..", "..", "plantilla.xlsx"),
      // Ruta absoluta desde process.cwd() — raíz real del proyecto
      path.join(process.cwd(), "plantilla.xlsx"),
      // Por si cwd apunta a netlify/functions
      path.join(process.cwd(), "..", "..", "plantilla.xlsx")
    ];
    console.log("[generar.js] Buscando plantilla en:");
    posiblesPaths.forEach((p) => console.log("  -", p, "\u2192", fs.existsSync(p) ? "\u2713 EXISTE" : "\u2717 no encontrada"));
    const templatePath = posiblesPaths.find((p) => fs.existsSync(p));
    if (!templatePath) {
      return {
        statusCode: 500,
        body: JSON.stringify({
          error: "plantilla.xlsx no encontrada en el servidor. Verifique que el archivo exista en la ra\xEDz del proyecto.",
          rutas_revisadas: posiblesPaths
        })
      };
    }
    console.log("[generar.js] Plantilla encontrada en:", templatePath);
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(templatePath);
    const ws = workbook.worksheets[0];
    if (!ws) {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "La plantilla no contiene ninguna hoja de trabajo." })
      };
    }
    setCellValue(ws, MAPA_CELDAS.fechaSolicitud, sanitizeString(data.fechaSolicitud));
    setCellValue(ws, MAPA_CELDAS.organizacion, sanitizeString(data.organizacion));
    setCellValue(ws, MAPA_CELDAS.nombreLider, sanitizeString(data.nombreLider));
    setCellValue(ws, MAPA_CELDAS.nombreReceptor_L8, sanitizeString(data.nombreReceptor));
    setCellValue(ws, MAPA_CELDAS.nombreReceptor_G22, sanitizeString(data.nombreReceptor));
    const textoTipo = generarTextoTipoSolicitud(sanitizeString(data.tipoSolicitud));
    setCellValue(ws, MAPA_CELDAS.tipoSolicitud, textoTipo);
    setCellValue(ws, MAPA_CELDAS.nombreActividad, sanitizeString(data.nombreActividad));
    setCellValue(ws, MAPA_CELDAS.fechaActividad, sanitizeString(data.fechaActividad));
    setCellValue(ws, MAPA_CELDAS.horaActividad, sanitizeString(data.horaActividad));
    setCellValue(ws, MAPA_CELDAS.lugar, sanitizeString(data.lugar));
    setCellValue(ws, MAPA_CELDAS.cantidadAsistencia, sanitizeNumber(data.cantidadAsistencia, 1));
    setCellValue(ws, MAPA_CELDAS.dirigidaA, sanitizeString(data.dirigidaA));
    setCellValue(ws, MAPA_CELDAS.proposito, sanitizeString(data.proposito));
    const METAS_MAP = {
      "edificarFe": MAPA_CELDAS.meta_edificarFe,
      "diversionUnidad": MAPA_CELDAS.meta_diversionUnidad,
      "crecimientoPersonal": MAPA_CELDAS.meta_crecimientoPersonal,
      "fortalecerFamilias": MAPA_CELDAS.meta_fortalecerFamilias,
      "obrasSalvacion": MAPA_CELDAS.meta_obrasSalvacion
    };
    Object.values(METAS_MAP).forEach((celda) => setCellValue(ws, celda, ""));
    const metas = Array.isArray(data.metas) ? data.metas : [];
    metas.forEach((meta) => {
      if (meta === "otra") {
        if (data.metaOtraTexto) {
          setCellValue(ws, "J25", "X");
          setCellValue(ws, "K25", sanitizeString(data.metaOtraTexto));
        }
      } else if (METAS_MAP[meta]) {
        setCellValue(ws, METAS_MAP[meta], "X");
      }
    });
    const productos = Array.isArray(data.productos) ? data.productos.slice(0, 13) : [];
    productos.forEach((prod, idx) => {
      const fila = PRODUCTO_INICIO_FILA + idx;
      setCellValue(ws, `${COLUMNA_CANTIDAD}${fila}`, sanitizeNumber(prod.cantidad, 0));
      setCellValue(ws, `${COLUMNA_PRODUCTO}${fila}`, sanitizeString(prod.producto));
      setCellValue(ws, `${COLUMNA_COSTO_UNIT}${fila}`, sanitizeNumber(prod.costoUnitario, 0));
      setCellValue(ws, `${COLUMNA_COSTO_TOTAL}${fila}`, sanitizeNumber(prod.costoTotal, 0));
    });
    const total = sanitizeNumber(data.totalSolicitado, 0);
    setCellValue(ws, MAPA_CELDAS.totalSolicitado_K42, total);
    setCellValue(ws, MAPA_CELDAS.totalSolicitado_L7, total);
    const buffer = await workbook.xlsx.writeBuffer();
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": 'attachment; filename="solicitud_presupuesto.xlsx"',
        "Content-Length": buffer.length.toString(),
        "Cache-Control": "no-store",
        // Seguridad básica
        "X-Content-Type-Options": "nosniff"
      },
      // Netlify Functions soporta body binario con isBase64Encoded
      body: buffer.toString("base64"),
      isBase64Encoded: true
    };
  } catch (err) {
    console.error("[generar.js] Error interno:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Error interno al generar el archivo Excel. Por favor intente nuevamente.",
        detail: process.env.NODE_ENV === "development" ? err.message : void 0
      })
    };
  }
};
